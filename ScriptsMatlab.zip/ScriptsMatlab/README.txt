Le fichier principal (main) est celui intitulé : ParamModif.m
Les autres fichiers inclus dans ce dossier ont été utilisés soit comme fonctions, soit pour alléger le script principal.

Xavier Kervyn